G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2025-11-08T22:04:33+01:00*
G04 #@! TF.ProjectId,receiver-board,72656365-6976-4657-922d-626f6172642e,1.0.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2025-11-08 22:04:33*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.140000X-0.140000X-0.170000X0.140000X-0.170000X0.140000X0.170000X-0.140000X0.170000X0*%
%ADD11C,1.300000*%
%ADD12R,2.300000X1.600000*%
%ADD13RoundRect,0.250200X0.649800X0.649800X-0.649800X0.649800X-0.649800X-0.649800X0.649800X-0.649800X0*%
%ADD14C,1.800000*%
%ADD15C,2.500000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,C6*
X38980000Y-37500000D03*
X38020000Y-37500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J2*
X37450000Y-48250000D03*
X37450000Y-41250000D03*
D12*
X41100000Y-48250000D03*
X33800000Y-48350000D03*
X41100000Y-45350000D03*
X33800000Y-41250000D03*
X41100000Y-39650000D03*
X33800000Y-39050000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,U2*
X45040000Y-35025000D03*
D14*
X42500000Y-35025000D03*
X39960000Y-35025000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,REF\u002A\u002A*
X35500000Y-35000000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X46000000Y-50000000D03*
G04 #@! TD*
M02*
