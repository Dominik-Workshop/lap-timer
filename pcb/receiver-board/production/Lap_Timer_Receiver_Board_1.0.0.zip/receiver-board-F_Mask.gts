G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2025-11-08T18:28:02+01:00*
G04 #@! TF.ProjectId,receiver-board,72656365-6976-4657-922d-626f6172642e,1.0.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2025-11-08 18:28:02*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.800000*%
%ADD11RoundRect,0.250200X0.649800X0.649800X-0.649800X0.649800X-0.649800X-0.649800X0.649800X-0.649800X0*%
%ADD12C,2.500000*%
%ADD13C,1.700000*%
%ADD14R,2.800000X2.200000*%
%ADD15R,2.800000X2.800000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,U2*
X40960000Y-33025000D03*
X43500000Y-33025000D03*
D11*
X46040000Y-33025000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,REF\u002A\u002A*
X35500000Y-32000000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X47000000Y-50000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X38000000Y-46500000D03*
X38000000Y-39500000D03*
D14*
X34300000Y-45600000D03*
X41700000Y-47600000D03*
D15*
X41700000Y-38200000D03*
G04 #@! TD*
M02*
